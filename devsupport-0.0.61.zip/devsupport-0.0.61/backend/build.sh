#!/usr/bin/env bash
docker build -t devsupport .
